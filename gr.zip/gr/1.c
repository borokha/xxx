#include<graphics.h>
#include<stdio.h>

int main()
{
	int gd=DETECT, gm,x;
	initgraph(&gd,&gm,NULL);
	putpixel(25,25,BLUE);
	scanf("%d",&x);
	closegraph();
	return 0;
}
