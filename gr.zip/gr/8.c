#include<stdio.h>
#include<graphics.h>

void rotation()
{

}

int main()
{
	int gd=DETECT,gm;
	initgraph(&gd,&gm,NULL);
	int x1=10,y1=10,x2=50,y2=100;





	sleep(5000);
	closegraph();
	return 0;
}
