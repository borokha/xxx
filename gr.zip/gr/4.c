#include<stdio.h>
#include<graphics.h>

void bresnhem(int x0, int y0, int x1, int y1)
{
	int dx=abs(x0-x1),dy=abs(y0-y1);
	int p = 2*dy-dx;
	int x,y,xEnd;
	if(x0>x1){
		x=x1;
		y=y1;
		xEnd = x1;
	}
	else{
		x=x0;
		y=y0;
		xEnd=x1;
	}

	putpixel(x,y,RED);

	while(x<xEnd){
		x++;
		if(p<0){
			p = p + 2*dy*x;
		}
		else{
			y++;
			p = p + 2*dy*x - 2*dx*y;
		}
		putpixel(x,y,RED);
	}

}

int main()
{
	int gd=DETECT,gm;
	initgraph(&gd,&gm,NULL);
	int x1=10,y1=10,x2=200,y2=100;

	bresnhem(x1,y1,x2,y2);



	sleep(5000);
	closegraph();
	return 0;
}
