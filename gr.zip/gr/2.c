#include<graphics.h>
#include<stdio.h>
int main()
{
	int gd=DETECT,gm,x1=10,y1=10,x2=100,y2=100;
	initgraph(&gd,&gm,NULL);
	setcolor(RED);
	line(x1,y1,x2,y2);
	sleep(100000);
	closegraph();
	return 0;
}
