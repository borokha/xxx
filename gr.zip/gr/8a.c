#include <graphics.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
int main()
{
            int gm;
            int gd=DETECT;
            int x1,y1,x2,y2,nx1t,ny1t,nx2t,ny2t;
            int nx1s,ny1s,nx2s,ny2s;
            int nx1r,ny1r,nx2r,ny2r;
            int sx,sy,xt,yt,r;
            float t;
            printf("\n\t Enter the points of line");
            scanf("%d%d%d%d",&x1,&y1,&x2,&y2);
            printf("\n Enter the translation factor");
                                    scanf("%d%d",&xt,&yt);
                                    nx1t=x1+xt;
                                    ny1t=y1+yt;
                                    nx2t=x2+xt;
                                    ny2t=y2+yt;
            
                                    
 	     printf("\n Enter the angle of rotation");
                                    scanf("%d",&r);
                                    t=3.14*r/180;
                                    nx1r=abs(x1*cos(t)-y1*sin(t));
                                    ny1r=abs(x1*sin(t)+y1*cos(t));
                                    nx2r=abs(x2*cos(t)-y2*sin(t));
                                    ny2r=abs(x2*sin(t)+y2*cos(t));
                                    
 	     printf("\n Enter the scaling factor");
                                    scanf("%d%d",&sx,&sy);
                                    nx1s=x1*sx;
                                    ny1s=y2*sy;
                                    nx2s=x2*sx;
                                    ny2s=y2*sy;
                                  
             initgraph(&gd,&gm,NULL);
             line(x1,y1,x2,y2);
  		                    line(nx1t,ny1t,nx2t,ny2t);
                                   
                                    line(nx1r,ny1r,nx2r,ny2r);
                                    line(nx1s,ny1s,nx2s,ny2s);
                                    
                                    delay(20000);
                                    closegraph();
				    return 0;
                                    }

