#include<stdio.h>
#include<graphics.h>

int main(){
	
	int n,i;
	int gd=DETECT,gm;
	printf("Enter n:");
	scanf("%d",&n);
	
	int points[2*n+2];
	printf("Enter coordinates:");
	for(i=0;i<2*n;i++)
		scanf("%d",&points[i]);

	initgraph(&gd,&gm,NULL);
	float x0=0,x1=getmaxx(),xmid=x1/2;
	float y0=0,y1=getmaxy(),ymid=y1/2;

	line(x0,y1/2,x1,y1/2);
	line(x1/2,y0,x1/2,y1);
	line(0,y1,x1,0);

	for(i=0;i<2*n;i+=2)
		points[i]+=xmid;
	drawpoly(n,points);
	
	int npoints[2*n];
	for(i=0;i<2*n;i++){
		if(i%2==0) npoints[i]=points[i];
		else npoints[i]=points[i]+2*(ymid-points[i]);
	}
	drawpoly(n,npoints);
	
	for(i=0;i<2*n;i++){
		if(i%2!=0) npoints[i]=points[i];
		else npoints[i]=points[i]-2*(points[i]-xmid);
	}
	drawpoly(n,npoints);
	
	float x,y,a,b;
	for(i=0;i<2*n-1;i+=2){
		a=points[i],b=points[i+1];
		x=(a*x1*x1+x1*y1*y1-b*x1*y1)/(x1*x1+y1*y1);
		y=(b*y1*y1+x1*x1*y1-a*x1*y1)/(x1*x1+y1*y1);
		npoints[i]=2*x-a;
		npoints[i+1]=2*y-b;
	}

	drawpoly(n,npoints);
	delay(10000);
	closegraph();
	return 0;
}

