#include<stdio.h>
#include<graphics.h>

int main(){
	int n,i;
	int gd=DETECT,gm;
	printf("Enter n:");
	scanf("%d",&n);
	int points[2*n],shx,shy;
	
	printf("Enter coordinates:");
	for(i=0;i<2*n;i++)
		scanf("%d",&points[i]);
	
	printf("Enter SHx and Shy:");
	scanf("%d%d",&shx,&shy);
	
	initgraph(&gd,&gm,NULL);
	drawpoly(n,points);
	
	int npoints[2*n];
	for(i=0;i<2*n;i++){
		if(i%2==0) npoints[i]=points[i]+shx*points[i+1];
		else npoints[i]=points[i];
	}
	drawpoly(n,npoints);
	for(i=0;i<2*n;i++){
		if(i%2!=0) npoints[i]=points[i]+shy*points[i-1];
		else npoints[i]=points[i];
	}
	
	drawpoly(n,npoints);
	delay(10000);
	closegraph();
	return 0;
}

