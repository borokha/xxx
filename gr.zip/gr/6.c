#include<stdio.h>
#include<graphics.h>

void midpoint(int x0,int y0,int r)
{
	putpixel(x0,y0,r);

	int p=1-r,x=0,y=r;

	while(x<=y){
		if(p<0){
			x++;
			p+=2*x+1;
		}
		else{
			x++,y--;
			p+=2*x+1-2*y;
		}
		putpixel(x+x0,y+y0,BLUE);
		putpixel(x+x0,-y+y0,BLUE);
		putpixel(-x+x0,y+y0,BLUE);
		putpixel(-x+x0,+y0-y,BLUE);
		putpixel(y+x0,x+y0,BLUE);
		putpixel(y+x0,-x+y0,BLUE);
		putpixel(-y+x0,x+y0,BLUE);
		putpixel(-y+x0,-x+y0,BLUE);
	}

}

int main()
{
	int gd=DETECT,gm;
	initgraph(&gd,&gm,NULL);
	int x0=50,y0=50,r=20;
	midpoint(x0,y0,r);




	sleep(5000);
	closegraph();
	return 0;
}
