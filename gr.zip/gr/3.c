#include<stdio.h>
#include<graphics.h>

void dda(int x0, int y0, int x1, int y1)
{
	int dx=x1-x0;
	int dy=y1-y0;

	int steps = (abs(dx)>abs(dy))?abs(dx):abs(dy);
	float xi = (float)dx/steps;
	float yi = (float)dy/steps;

	float x=x0,y=y0;
	for(int i=0;i<steps; i++){
		putpixel(x,y,RED);
		x+=xi;
		y+=yi;
	}
}

int main()
{
	int gd=DETECT,gm;
	initgraph(&gd,&gm,NULL);
	int x1=10,y1=10,x2=50,y2=100;

	dda(x1,y1,x2,y2);






	sleep(5000);
	closegraph();
	return 0;
}

