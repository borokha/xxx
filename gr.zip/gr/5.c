#include<stdio.h>
#include<graphics.h>

void bres(int x0,int y0,int r)
{
	int d = 3 - 2*r;
	int x=0,y=r;

	while(x<=y){

		if(d<0){
			x++;
			d = d + 4*x;
		}
		else{
			x++,y--;
			d = d + 4*(x-y)+10;
		}
		putpixel(x+x0,y+y0,BLUE);
		putpixel(x+x0,-y+y0,BLUE);
		putpixel(-x+x0,y+y0,BLUE);
		putpixel(-x+x0,-y+y0,BLUE);
		putpixel(y+x0,x+y0,BLUE);
		putpixel(y+x0,-x+y0,BLUE);
		putpixel(-y+x0,x+y0,BLUE);
		putpixel(-y+x0,-x+y0,BLUE);
	}

}

int main()
{
	int gd=DETECT,gm;
	initgraph(&gd,&gm,NULL);
	int x1=10,y1=10,x2=50,y2=100;
	bres(50,50,10);




	sleep(5000);
	closegraph();
	return 0;
}
